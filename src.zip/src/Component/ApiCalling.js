import axios from "axios";

export const LoginApi = async (userCredentials) => {
  let url = "https://fakestoreapi.com/auth/login";

  let res = await axios
    .post(url, {
      username: userCredentials?.username,
      password: userCredentials?.password,
    })
    .then((res) => {
      return res;
    })
    .catch((e) => {
      return e;
    });

  return res;
};

export const getProducts = async (param) => {
  let url = param;
  let res = await axios
    .get(url)
    .then((res) => {
      return res;
    })
    .catch((e) => {
      return e;
    });
  return res;
};
