import { useState } from "react";
import { LoginApi } from "./ApiCalling";
import CircularProgress from "@mui/material/CircularProgress";
import NavBar from "./NavBar";

const Login = () => {
  const [inputUserName, setInputUserName] = useState(""); //mor_2314
  const [inputPassWord, setInputPassWord] = useState(""); //83r5^_
  const [loading, setLoading] = useState(false);
  const [msg, setMesg] = useState("");
  const [isUserLogin, setIsUserLogin] = useState(false);

  const handleSubmit = async () => {
    let obj = {
      username: inputUserName,
      password: inputPassWord,
    };
    setLoading(true);
    const loginResponse = await LoginApi(obj);
    setLoading(false);
    setInputPassWord("");
    setInputUserName("");
    if (loginResponse?.status == 200 && loginResponse?.data?.token) {
      sessionStorage.setItem("userLogin", loginResponse?.data?.token);
      setIsUserLogin(true);
    } else {
      setIsUserLogin(false);
      setMesg(loginResponse?.response?.data);
      setTimeout(() => {
        setMesg("");
      }, 2000);
    }

    console.log("loginResponse:", loginResponse);
  };

  return (
    <div>
      {loading && <CircularProgress />}

      {!isUserLogin ? (
        <>
          <div>login Page </div>
          <div>
            <div
              className="LoginMainDiv"
              style={{ display: "grid", justifyContent: "center", gap: "15px" }}
            >
              <input
                placeholder="enter username"
                style={{ width: "15rem" }}
                value={inputUserName}
                onChange={(e) => setInputUserName(e.target.value)}
              />
              <input
                placeholder="enter Password"
                style={{ width: "15rem" }}
                value={inputPassWord}
                onChange={(e) => setInputPassWord(e.target.value)}
              />
              <button onClick={handleSubmit}>Submit</button>
            </div>{" "}
            <p style={{ color: "red" }}>{msg}</p>
          </div>
        </>
      ) : (
        <NavBar setIsUserLogin={setIsUserLogin} />
      )}
    </div>
  );
};

export default Login;
