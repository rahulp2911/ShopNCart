import * as React from "react";
import { useState, useEffect } from "react";
import { getProducts } from "./ApiCalling";
import CircularProgress from "@mui/material/CircularProgress";

import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";

export default function NavBar({ setIsUserLogin }) {
  const [msg, setMesg] = useState("");
  const [products, setProducts] = useState([]);
  const [selectedProducts, setSelectedProducts] = useState([]);
  const [onView, setOnView] = useState("allProducts");

  useEffect(() => {
    allProducts();
  }, []);

  const handleLogout = () => {
    sessionStorage.setItem("userLogin", "");
    setIsUserLogin(false);
  };

  const allProducts = async () => {
    setOnView("allProducts");
    let url = "https://fakestoreapi.com/products";

    const getData = await getProducts(url);
    if (getData.status == 200) {
      setProducts(getData?.data ?? []);
    } else {
      setMesg("error..please try again");
      setTimeout(() => {
        setMesg("");
      }, 2000);
    }
  };

  const handleSelectedProducts = (obj) => {
    let existingArray = selectedProducts.filter(
      (proObj) => proObj.id == obj.id
    );

    if (existingArray.length === 0) {
      setSelectedProducts((prev) => {
        return [...prev, obj];
      });
    }
  };

  const handleCart = (view) => {
    setOnView(view);
  };

  console.log("products:", products);

  console.log("selectedProducts:", selectedProducts);

  const handleReomveProducts = (obj) => {
    let newArray = selectedProducts.filter((productsObj, index) => {
      return productsObj?.id !== obj?.id;
    });
    setSelectedProducts(newArray);
  };

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static">
        <Toolbar
          className="ToolbarMui"
          style={{ justifyContent: "space-between" }}
        >
          <div className="NavBar" style={{ display: "flex " }}>
            <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
              News
            </Typography>
          </div>
          <div className="TabButton">
            <Button color="inherit" onClick={() => allProducts()}>
              All Products
            </Button>
            <Button color="inherit" onClick={() => handleCart("cart")}>
              Cart
            </Button>
            <Button style={{ color: "yellow" }} onClick={handleLogout}>
              logout
            </Button>
          </div>
        </Toolbar>
      </AppBar>
      {/* ---------panel------------------- */}
      {msg && <>{msg}</>}
      <div style={{ display: "flex", flexWrap: "wrap", gap: "1rem" }}>
        {(onView === "cart" ? selectedProducts : products)?.map(
          (obj, index) => (
            <div
              style={{
                width: "8rem",
                padding: "1rem",
                border: "1px solid black",
                display: "grid",
              }}
            >
              <img
                style={{ width: "6rem", height: "6rem" }}
                src={obj?.image ?? ""}
              />
              price:{obj?.price ?? ""}
              {onView === "cart" ? (
                <button onClick={() => handleReomveProducts(obj)}>
                  Remove
                </button>
              ) : (
                <button onClick={() => handleSelectedProducts(obj)}>
                  Add to cart
                </button>
              )}
            </div>
          )
        )}
      </div>
      {(onView === "cart" ? selectedProducts : products).length === 0 && (
        <>no Data</>
      )}
    </Box>
  );
}
