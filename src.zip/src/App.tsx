import React from "react";
import "./App.css";

import Login from "./Component/Login";

function App() {
  // let a = sessionStorage.getItem("userLogin");
  // console.log("a:", a);

  // React.useEffect(() => {}, [a]);

  return (
    <div className="App">
      <Login />
    </div>
  );
}

export default App;
